# Security Policy

If you discover a vulnerability, please open a private security advisory or email the maintainer.
